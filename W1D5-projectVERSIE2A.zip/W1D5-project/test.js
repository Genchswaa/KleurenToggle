
//PROJECT KLEURENTOGGLE / Verbeterde versie

//______hamburger moet menu in/uit klappen bij click________________________________

//Img moet een queryselector krigen. Krijgt naam hamburger
const img = document.querySelector('hamburger');
//kleurenMenu verwijst naar de ul/kleurenlijst. Class heet kleurenMenu.
const kleurenMenu = document.getElementById('kleurenMenu')
//click, function. Hierin geef ik aan wat er moet gebeuren als ik klik.
//Hamburger krijgt een klikfunctie door addEventListerer.
hamburger.addEventListener('click', function(){
// Ik wil dat kleurenmenu de functies onder menuToggle in de css krijgt.
    kleurenMenu.classList.toggle('menuToggle');
});

    //__Menu/ activeren achtergrondkleur// terugklappen menu______________________________________________

// Achtergrond moet nog worden defined. Hele pagina is dus 'body veranderen.
// Ik geef een naam mee aan het begin en die komt weer in de function.
    const achterKleur = document.querySelector('body');

    // Elke kleur pak ik bij de ID en define ik. Deze geef ik dezelfde naam.
    // Ik geef groen een klikfunctie en ik zeg wat ik wil wat er gebeurt bij de klik.
    const groen = document.getElementById('groen')
    groen.addEventListener('click', function(){
        // Deze is voor het vakje zelf.
        this.style.backgroundColor = 'green';
        //Deze is voor de hele pagina want achterKleur = 'body.
        achterKleur.style.backgroundColor = 'green';
        //Deze is voor de css 
        kleurenMenu.classList.toggle('menuToggle');
    });
    
//___ Voor elke kleur hetzelfde toepassen. 
    const geel = document.getElementById('geel')
    geel.addEventListener('click', function(){
        this.style.backgroundColor = 'yellow';
        achterKleur.style.backgroundColor = 'yellow';
        kleurenMenu.classList.toggle('menuToggle');
    });

    const rood = document.getElementById('rood')
    rood.addEventListener('click', function(){
        this.style.backgroundColor = 'red';
        achterKleur.style.backgroundColor = 'red';
        kleurenMenu.classList.toggle('menuToggle');
    });

    const blauw = document.getElementById('blauw')
    blauw.addEventListener('click', function(){
        this.style.backgroundColor = 'blue';
        achterKleur.style.backgroundColor = 'blue';
        kleurenMenu.classList.toggle('menuToggle');
    });

